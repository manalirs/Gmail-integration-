//
//  ViewController.swift
//  new
//
//  Created by Mac on 31/01/2020.
//  Copyright © 2020 Mac. All rights reserved.
//

import UIKit
import GoogleSignIn
class ViewController: UIViewController {
@IBOutlet weak var signInButton: GIDSignInButton!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var btn: UIButton!
    @IBAction func btn1(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        view1.layer.cornerRadius = 10
        view1.clipsToBounds = true
        btn.layer.cornerRadius = 10
        btn.clipsToBounds = true
    view1.isHidden = true
        
        GIDSignIn.sharedInstance().scopes.append("https://www.googleapis.com/auth/plus.login")
        GIDSignIn.sharedInstance().scopes.append("https://www.googleapis.com/auth/plus.me")
            GIDSignIn.sharedInstance()?.presentingViewController = self
           //  GIDSignIn.sharedInstance()?.signInSilently()
            // Automatically sign in the user.
          GIDSignIn.sharedInstance()?.restorePreviousSignIn()
            
            // ...
        
    }
    @IBAction func didTapSignOut(_ sender: AnyObject) {
        GIDSignIn.sharedInstance().signOut()
    }

}

